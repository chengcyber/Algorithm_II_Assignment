
public class LexNode{
	public boolean isWord;
	public boolean isDetected;
	public LexNode[] next = new LexNode[R];
	
	private static final int R = 26;
}
